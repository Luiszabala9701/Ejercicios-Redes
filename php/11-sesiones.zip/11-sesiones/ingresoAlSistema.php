<?php
// ingresoAlSistema.php - Procesa el login y muestra la información de sesión

session_start();

require_once 'libreria.inc';

// Procesar el formulario de login si viene por POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $login = $_POST['login'] ?? '';
  $clave = $_POST['clave'] ?? '';
  
  // Validar que no estén vacíos
  if (empty($login) || empty($clave)) {
    header('Location: formularioLogin.html?error=1');
    exit;
  }
  
  // Autenticar usuario
  $usuario = autenticarUsuario($login, $clave);
  
  if ($usuario) {
    // Usuario válido - Crear sesión
    
    // Verificar si es una nueva sesión (no recargar)
    $esNuevaSesion = !isset($_SESSION['usuario_id']);
    
    $_SESSION['usuario_id'] = $usuario['idUsuario'];
    $_SESSION['usuario_login'] = $usuario['nombreUsuario'];
    $_SESSION['usuario_apellido'] = $usuario['apellido'];
    $_SESSION['usuario_nombres'] = $usuario['nombres'];
    
    // Incrementar contador solo si es una nueva sesión
    if ($esNuevaSesion) {
      incrementarContadorSesion($usuario['idUsuario']);
    }
    
    // Obtener el contador actualizado
    $contador = obtenerContadorSesion($usuario['idUsuario']);
    $_SESSION['contador_sesion'] = $contador;
    
  } else {
    // Usuario inválido - Volver al login con error
    header('Location: formularioLogin.html?error=1');
    exit;
  }
}

// Verificar si hay sesión activa
if (!isset($_SESSION['usuario_id'])) {
  header('Location: formularioLogin.html');
  exit;
}

// Obtener datos de sesión
$sessionId = session_id();
$loginUsuario = $_SESSION['usuario_login'];
$contadorSesion = $_SESSION['contador_sesion'];
$nombreCompleto = $_SESSION['usuario_apellido'] . ' ' . $_SESSION['usuario_nombres'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Información de Sesión</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: Arial, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      padding: 20px;
    }

    .container {
      background: white;
      border-radius: 15px;
      box-shadow: 0 15px 35px rgba(0, 0, 0, 0.3);
      padding: 40px;
      max-width: 600px;
      width: 100%;
    }

    .header {
      text-align: center;
      margin-bottom: 30px;
      padding-bottom: 20px;
      border-bottom: 3px solid #667eea;
    }

    .header h1 {
      color: #667eea;
      font-size: 1.8rem;
      margin-bottom: 10px;
    }

    .info-section {
      margin: 25px 0;
    }

    .info-item {
      background: #f8f9fa;
      padding: 15px 20px;
      margin: 12px 0;
      border-radius: 8px;
      border-left: 4px solid #667eea;
    }

    .info-item strong {
      color: #333;
      display: inline-block;
      min-width: 200px;
      font-size: 1rem;
    }

    .info-item span {
      color: #667eea;
      font-weight: 600;
      font-size: 1rem;
    }

    .buttons {
      display: flex;
      gap: 15px;
      margin-top: 30px;
      flex-wrap: wrap;
    }

    .btn {
      flex: 1;
      min-width: 200px;
      padding: 15px 25px;
      border: none;
      border-radius: 8px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      text-align: center;
      text-decoration: none;
      display: inline-block;
    }

    .btn-primary {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
    }

    .btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
    }

    .btn-secondary {
      background: #6c757d;
      color: white;
    }

    .btn-secondary:hover {
      background: #5a6268;
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(108, 117, 125, 0.4);
    }

    .welcome-message {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 20px;
      border-radius: 8px;
      text-align: center;
      margin-bottom: 25px;
      font-size: 1.1rem;
    }

    @media (max-width: 600px) {
      .container {
        padding: 25px;
      }

      .buttons {
        flex-direction: column;
      }

      .btn {
        width: 100%;
      }

      .info-item strong {
        display: block;
        margin-bottom: 5px;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Ingreso a la aplicación</h1>
    </div>

    <div class="welcome-message">
      Bienvenido/a <?php echo htmlspecialchars($nombreCompleto); ?>
    </div>

    <div class="info-section">
      <h2 style="color: #333; margin-bottom: 15px; font-size: 1.3rem;">Información de Sesión</h2>
      
      <div class="info-item">
        <strong>Identificativo de sesión:</strong>
        <span><?php echo htmlspecialchars($sessionId); ?></span>
      </div>

      <div class="info-item">
        <strong>Login de usuario:</strong>
        <span><?php echo htmlspecialchars($loginUsuario); ?></span>
      </div>

      <div class="info-item">
        <strong>Contador de sesión:</strong>
        <span><?php echo htmlspecialchars($contadorSesion); ?></span>
      </div>
    </div>

    <div class="buttons">
      <a href="app_modulo_1/index.php" class="btn btn-primary">
        Ingrese al módulo 1 de la app
      </a>
      <a href="destruirSesion.php" class="btn btn-secondary">
        Termina sesión
      </a>
    </div>
  </div>
</body>
</html>
