﻿<?php
// alta.php - Inserta nueva factura
session_start();
require_once __DIR__ . '/../manejoSesion.inc';

header('Content-Type: text/html; charset=utf-8');
require_once __DIR__ . '/datosConexionBase.php';

$respuesta = "Alta de registro<br>";

try {
  $pdo = conectarBaseDatos();

  $NroFactura       = $_POST['NroFactura']        ?? '';
  $CodProveedor     = $_POST['CodProveedor']      ?? '';
  $DomicilioProv    = $_POST['DomicilioProveedor']?? '';
  $FechaFactura     = $_POST['FechaFactura']      ?? '';
  $CodPlazosEntrega = $_POST['CodPlazosEntrega']  ?? '';
  $TotalNeto        = $_POST['TotalNetoFactura']  ?? 0;

  $sql = "INSERT INTO factura
          (NroFactura, CodProveedor, DomicilioProveedor, FechaFactura, CodPlazosEntrega, TotalNetoFactura)
          VALUES (:NroFactura,:CodProveedor,:DomicilioProveedor,:FechaFactura,:CodPlazosEntrega,:TotalNetoFactura)";
  
  $stmt = $pdo->prepare($sql);
  $stmt->bindParam(':NroFactura', $NroFactura);
  $stmt->bindParam(':CodProveedor', $CodProveedor);
  $stmt->bindParam(':DomicilioProveedor', $DomicilioProv);
  $stmt->bindParam(':FechaFactura', $FechaFactura);
  $stmt->bindParam(':CodPlazosEntrega', $CodPlazosEntrega);
  $stmt->bindParam(':TotalNetoFactura', $TotalNeto);
  $stmt->execute();
  $respuesta .= "Registro insertado correctamente<br>";

  if (isset($_FILES['PdfComprobante']) && $_FILES['PdfComprobante']['error'] === UPLOAD_ERR_OK) {
    $contenidoPdf = file_get_contents($_FILES['PdfComprobante']['tmp_name']);
    $esPdf = (substr($contenidoPdf,0,5) === '%PDF-' || substr($contenidoPdf,0,4) === '%PDF');
    
    if ($esPdf) {
      $sql2 = "UPDATE factura SET PdfComprobante=:pdf WHERE NroFactura=:NroFactura";
      $stmt2 = $pdo->prepare($sql2);
      $stmt2->bindParam(':pdf', $contenidoPdf, PDO::PARAM_LOB);
      $stmt2->bindParam(':NroFactura', $NroFactura);
      $stmt2->execute();
      $respuesta .= "PDF adjunto guardado<br>";
    } else {
      $respuesta .= "Archivo rechazado: no es un PDF válido<br>";
    }
  }

} catch (Exception $e) {
  $respuesta .= "Error: " . htmlspecialchars($e->getMessage()) . "<br>";
}

echo $respuesta;
