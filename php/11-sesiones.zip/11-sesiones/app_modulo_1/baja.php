<?php
// baja.php - Elimina un registro de factura
session_start();
require_once __DIR__ . '/../manejoSesion.inc';

header('Content-Type: text/html; charset=utf-8');
require_once __DIR__ . '/datosConexionBase.php';

$respuesta = "Baja de registro<br>";
try {
    $pdo = conectarBaseDatos();
    $NroFactura = $_POST['NroFactura'] ?? '';

    $sql = "DELETE FROM factura WHERE NroFactura = :NroFactura";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':NroFactura', $NroFactura);
    $stmt->execute();
    
    $respuesta .= "Registro eliminado correctamente<br>";

} catch (Exception $e) {
    $respuesta .= "Error: " . htmlspecialchars($e->getMessage()) . "<br>";
}

echo $respuesta;
