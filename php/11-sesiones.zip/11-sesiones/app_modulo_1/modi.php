﻿<?php
// modi.php - Modifica un registro de factura
session_start();
require_once __DIR__ . '/../manejoSesion.inc';

header('Content-Type: text/html; charset=utf-8');
require_once __DIR__ . '/datosConexionBase.php';

$respuesta = "Modificación de registro<br>";

try {
  $pdo = conectarBaseDatos();

  $NroFactura       = $_POST['NroFactura']        ?? '';
  $CodProveedor     = $_POST['CodProveedor']      ?? '';
  $DomicilioProv    = $_POST['DomicilioProveedor']?? '';
  $FechaFactura     = $_POST['FechaFactura']      ?? '';
  $CodPlazosEntrega = $_POST['CodPlazosEntrega']  ?? '';
  $TotalNeto        = $_POST['TotalNetoFactura']  ?? 0;

  $sql = "UPDATE factura SET
            CodProveedor=:CodProveedor,
            DomicilioProveedor=:DomicilioProveedor,
            FechaFactura=:FechaFactura,
            CodPlazosEntrega=:CodPlazosEntrega,
            TotalNetoFactura=:TotalNetoFactura
          WHERE NroFactura=:NroFactura";

  $stmt = $pdo->prepare($sql);
  $stmt->bindParam(':CodProveedor', $CodProveedor);
  $stmt->bindParam(':DomicilioProveedor', $DomicilioProv);
  $stmt->bindParam(':FechaFactura', $FechaFactura);
  $stmt->bindParam(':CodPlazosEntrega', $CodPlazosEntrega);
  $stmt->bindParam(':TotalNetoFactura', $TotalNeto);
  $stmt->bindParam(':NroFactura', $NroFactura);
  $stmt->execute();
  $respuesta .= "Datos actualizados correctamente<br>";

  if (isset($_FILES['PdfComprobante']) && $_FILES['PdfComprobante']['error'] === UPLOAD_ERR_OK) {
    $contenidoPdf = file_get_contents($_FILES['PdfComprobante']['tmp_name']);
    $esPdf = (substr($contenidoPdf,0,5) === '%PDF-' || substr($contenidoPdf,0,4) === '%PDF');
    
    if ($esPdf) {
      $sql2 = "UPDATE factura SET PdfComprobante=:pdf WHERE NroFactura=:NroFactura";
      $stmt2 = $pdo->prepare($sql2);
      $stmt2->bindParam(':pdf', $contenidoPdf, PDO::PARAM_LOB);
      $stmt2->bindParam(':NroFactura', $NroFactura);
      $stmt2->execute();
      $respuesta .= "PDF actualizado<br>";
    } else {
      $respuesta .= "Archivo rechazado: no es un PDF válido<br>";
    }
  }

} catch (Exception $e) {
  $respuesta .= "Error: ".htmlspecialchars($e->getMessage())."<br>";
}

echo $respuesta;
