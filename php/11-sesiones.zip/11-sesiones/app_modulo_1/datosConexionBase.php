<?php
// datosConexionBase.php - ConexiÃ³n a la base de datos
function conectarBaseDatos() {
  $servidor = "localhost";
  $usuario  = "root";
  $clave    = "";
  $base     = "encabezado_factura";

  try {
    $pdo = new PDO("mysql:host=$servidor;dbname=$base;charset=utf8mb4",$usuario,$clave,[
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    return $pdo;
  } catch (PDOException $e) {
    $puntero = fopen(__DIR__."/errores.log","a");
    fwrite($puntero, date("Y-m-d H:i")." | Error conexiÃ³n: ".$e->getMessage()."\n");
    fclose($puntero);
    http_response_code(500);
    echo "Error en conexiÃ³n con la base.";
    exit;
  }
}